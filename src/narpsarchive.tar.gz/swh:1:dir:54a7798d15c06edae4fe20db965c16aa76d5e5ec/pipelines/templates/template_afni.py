#!/usr/bin/python
# coding: utf-8

"""
This template can be use to reproduce a pipeline using AFNI as main software.

- Replace all occurrences of 48CD by the actual id of the team.
- All lines starting with [INFO], are meant to help you during the reproduction, these can be removed
eventually.
- Also remove lines starting with [TODO], once you did what they suggested.
"""
